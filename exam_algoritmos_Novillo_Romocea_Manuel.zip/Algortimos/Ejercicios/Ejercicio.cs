﻿using System;

namespace Algoritmos.Ejercicios
{
    public abstract class Ejercicio
    {
        public abstract void ejecutar();
    }
}
