﻿using System;

namespace Algoritmos.Ejercicios
{
    internal class Ejercicio0 : Ejercicio
    {
        public Ejercicio0() { }

        public override void ejecutar()
        {
            Console.Clear();
            Console.WriteLine("\n\nMuchas gracias por usar nuestro programa de Algoritmos");
            Console.WriteLine("\n¡¡VUELVA PRONTO!!");
        }
    }
}
